var express = require('express');
var app = express();
var port = process.env.PORT||3015;
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var configDB = require('./config/database.js');
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var flash = require('connect-flash');
var session = require('express-session');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(session({secret:'secretpassword',
   saveUninitialized:true,
   resave: true}));

mongoose.connect(configDB.url);
require('./config/passport')(passport);
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

var starstore = require('./routes/starstore');

app.use('/starstore/', starstore);

app.post('/login', function(req, res, next) {
  passport.authenticate('local-login', function(err, user, info) {
    if (err) return next(err);
    if (!user) {
      res.status(403);
      return res.json({'status':403, 'message':'Invalid user or password'})
    }
    req.logIn(user, function(err) {
      if (err) return next(err);
      return res.json({'status':200, 'message':'Login successful'})
    });
  })(req, res, next);
});

app.post('/signup', function(req, res, next) {
  passport.authenticate('local-signup', function(err, user, info) {
    if (err) return next(err);
    if (user == false) {
      return res.json({'status':200, 'message':'Signup failed, user already taken'})
    }
      return res.json({'status':200, 'message':'Signup successful'})
  })(req, res, next);
});


app.listen(port);

console.log('Server running on port  ' + port);
