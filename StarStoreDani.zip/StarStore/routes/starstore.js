var express = require('express');
var router = express.Router();
var Mongoose = require('mongoose');
var Product = require('../app/models/product.js');
var Transaction = require('../app/models/transaction.js');

router.post('/product', function(req, res) {
  if (req.isAuthenticated()) {
    var newProduct = new Product(req.body);
    newProduct.save(function(e){
        if(e){
            console.log(e);
        } else {
          res.json({'message':'product saved!'});
        }
    })
  } else {
    res.json({'status':403, 'message': 'authentication required'});
  }
});

//Fiz sem autenticação, pois assim qualquer um consegue ver os produtos a serem vendidos!
router.get('/products', function(req, res){
    Product.find(function(err, doc) {
      if (err) {
        return console.error(err);
      }
      res.send(JSON.stringify(doc));
    })
});

router.post('/buy', function(req, res) {
  if (req.isAuthenticated()) {
  var newTransaction = new Transaction(req.body);
    newTransaction.save(function(e) {
      if (e) {
        console.log(e);
      } else {
        res.json({'message':'transaction saved!'});
      }
    })
   } else {
      res.json({'status':403, 'message': 'authentication required'});
    }
})


router.get('/history', function(req, res){
  if (req.isAuthenticated()) {
    Transaction.find({},{'client_id': true, '_id':true, 'credit_card.value': true, 'credit_card.card_number':true, 'date':true},function(err, doc) {
      if (err) {
        return console.error(err);
      }
      res.send(JSON.stringify(doc));
    })
    } else {
       res.json({'status':403, 'message': 'authentication required'});
     }
});



router.get('/history/:clientId', function(req,res){
  if (req.isAuthenticated()) {
  var clientId = req.params.clientId;
  Transaction.find({'client_id':clientId}, function(err, doc) {
    if (err) {
      return console.log(err)
    }
    res.send(JSON.stringify(doc));
  });
  } else {
     res.json({'status':403, 'message': 'authentication required'});
   }
});


module.exports = router;
