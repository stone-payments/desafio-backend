var Mongoose = require('mongoose');

var userSchema = Mongoose.Schema({
    username: {
      type: String,
      required: true
    },
    password: {
      type: String,
      required: true
    }
});

module.exports = Mongoose.model('User', userSchema);
