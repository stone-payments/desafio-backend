var Mongoose = require('mongoose');

var today = new Date();

var transactionSchema = Mongoose.Schema({
    client_id: {
      type: String,
      required: true
    },
    client_name: {
      type: String,
      required: true
    },
    total_to_pay: {
      type: Number,
      required: true
    },
    credit_card: {
        card_number: {
          type: String,
          required: true
        },
        card_holder_name: {
          type: String,
          required: true
        },
        value: {
          type: Number,
          required: true
        },
        cvv: {
          type: Number,
          required: true
        },
        exp_date: {
          type: String,
          required: true
        }
    },
    date: {
      type: String,
      default: (today.getDate()) + "/" + (today.getMonth()+1) + "/" + (today.getFullYear())
    }

});

module.exports = Mongoose.model('Transaction', transactionSchema);
