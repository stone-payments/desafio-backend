var Mongoose = require('mongoose');

var today = new Date();

var productSchema = Mongoose.Schema({
    title: {
      type: String,
      required: true
    },
    price: {
      type: Number,
      required: true
    },
    zipcode: {
      type: String,
      required: true
    },
    seller: {
      type: String,
      required: true
    },
    thumbnailHd:{
      type: String,
      required: true
    },
    date: {
      type: String,
      default: (today.getDate()) + "/" + (today.getMonth()+1) + "/" + (today.getFullYear())
    }

});

module.exports = Mongoose.model('Product', productSchema);
