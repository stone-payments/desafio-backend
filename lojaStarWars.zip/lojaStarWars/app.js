var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

app.use(bodyParser.json());

Product = require('./models/products');
Transaction = require('./models/transactions');


//Connect to Mongoose
mongoose.connect('mongodb://localhost/starstore');
var db = mongoose.connection;


app.get('/', function(req, res){

	res.send('Please use /starstore/products or /starstore/history');

});

app.post('/starstore/product', function(req, res){
	var product = req.body;
	Product.addProduct(product, function(err, product){
		if(err){
			throw err;
		}
		res.json(product);
	});

});

app.get('/starstore/products', function(req, res){

	Product.getProducts(function(err, products){
		if(err){
			throw err;
		}
		res.json(products);
	});

});

app.post('/starstore/buy', function(req, res){
	var transaction = req.body;
	Transaction.addTransaction(transaction, function(err, transaction){
		if(err){
			throw err;
		}
		res.json(transaction);
	});

});

app.get('/starstore/history', function(req, res){

	Transaction.getTransactions(function(err, transactions){
		if(err){
			throw err;
		}
		res.json(transactions);
	});

});

app.get('/starstore/history/:client_id', function(req, res){

	Transaction.getTransactionByClientId(req.params.client_id, function(err, transaction){
		if(err){
			throw err;
		}
		res.json(transaction);
	});

});

app.listen(3000);
console.log('running on port 3000...');
















