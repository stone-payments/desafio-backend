var mongoose = require('mongoose');

var date = new Date();

// Credit Card Schema
var creditCardSchema = mongoose.Schema({

	card_number:{
		type: String,
		required: true
	},
	card_holder_name:{
		type: String,
		required: true
	},
	value:{
		type: Number,
		required: true
	},
	cvv:{
		type: Number,
		required: true
	},
	exp_date:{
		type: String,
		required: true
	}
},{ _id : false });

// Transaction Schema
var transactionSchema = mongoose.Schema({

	client_id:{
		type: String,
		required: true
	},
	client_name:{
		type: String,
		required: true
	},
	total_to_pay:{
		type: Number,
		required: true
	},
	credit_card:{
		type: creditCardSchema,
		required: true
	},
	date:{
		type: String,
		default: (date.getDate()) + "/" + (date.getMonth()+1) + "/" + (date.getFullYear())
	}
});

var Transaction = module.exports = mongoose.model('Transaction', transactionSchema);

//Add Transaction
module.exports.addTransaction = function(transaction, callback){

	Transaction.create(transaction, callback);

}

// Get Transactions
module.exports.getTransactions = function(callback){

	Transaction.find(callback).select('_id client_id credit_card.value date credit_card.card_number');

}

// Get Transaction
module.exports.getTransactionByClientId = function(clientId, callback){

	Transaction.find({client_id: clientId}, callback).select('_id client_id credit_card.value date credit_card.card_number');

}

















