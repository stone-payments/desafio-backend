var mongoose = require('mongoose');

var date = new Date();

// Product Schema
var productSchema = mongoose.Schema({

	title:{
		type: String,
		required: true
	},
	price:{
		type: Number,
		required: true
	},
	zipcode:{
		type: String,
		required: true
	},
	seller:{
		type: String,
		required: true
	},
	thumbnailHd:{
		type: String,
		required: true
	},
	date:{
		type: String,
		default: (date.getDate()) + "/" + (date.getMonth()+1) + "/" + (date.getFullYear())
	}
});

var Product = module.exports = mongoose.model('Product', productSchema);

//Add Product
module.exports.addProduct = function(product, callback){

	Product.create(product, callback);

}

// Get Products
module.exports.getProducts = function(callback){

	Product.find(callback).select('-_id title price zipcode seller thumbnailHd date');

}















